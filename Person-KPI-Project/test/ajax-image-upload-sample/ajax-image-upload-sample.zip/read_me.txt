#Website	http://www.sanwebe.com/2012/05/ajax-image-upload-and-resize-with-jquery-and-php
#License	http://opensource.org/licenses/MIT

#Instructions
1. Copy all files to a directory within your website.
2. Make changes in processupload.php config, such as upload path, image size etc.
3. Open your browser and navigate to index.php